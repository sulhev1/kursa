<?php 
include "db.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <script src="script.js"></script>
    <link rel="stylesheet" href="style.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php print $titl; ?></title>
</head>
<body>
    <header>
        <div class="shirina">
            <a href="index.php">Главная</a>
            <div class="htext">Шаурма</div>
            <div class="htext">Гарниры</div>
            <div class="htext">Напитки</div>
            <div class="htext">Соуса</div>
        </div>
    </header>
