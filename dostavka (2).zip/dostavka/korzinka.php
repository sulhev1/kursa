<?php 
$titl="Корзина";
include "header.php";
?>
<main>
    <div class="zag">Корзина</div>
    <div class="stolbec">
        <div class="podzag">Фото</div>
        <div class="podzag">Название</div>
        <div class="podzag">Цена</div>
        <div class="podzag">Количество</div>
        <div class="podzag">Итоговая</div>
    </div>
    <table>
        <thead>
            <tr>
                <th>Фото</th>
                <th>Заголовок 2</th>
                <th>Заголовок 1</th>
                <th>Заголовок 2</th>
                <th>Заголовок 1</th>
            </tr>
        </thead>
    </table>
</main>