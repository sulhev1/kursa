<?php
include "php/httpdata.php";
include "php/sql.php";

const DB_HOST ="localhost";
const DB_USER ="user08";
const DB_PASS ="l3ZzFL3T";
const DB_NAME ="user08";
const MEDIA_PATH = 'http://192.168.0.125/125/zhiguli';

// Константы уровней пользователей
const ADMIN_LEVEL = 2;
const USER_LEVEL = 1;
const GUEST_LEVEL = 0;

// Константы статуса оюъектов
const STATUS_HIDDEN = 0;    // Объект скрыт (не опубликован)
const STATUS_SHOW = 1;		// Объект виден (опубликован)
const STATUS_CHECK = 2;		// Объект требует проверки
const STATUS_DRAFT = 3;		// Черновик объекта
const STATUS_FIXED = 10;

// Количество статей на странице
const POSTS_IN_PAGE = 20;

//подключение с помощью функции
$db = @mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Проверка сессии
session_start();
$user_id = SESSI('user_id');
$user_level = SESSI('user_level');
$user_name = SESSS('user_name');

// Получаем адрес текущего скрипта без расширения ".php"
$current_page = basename($_SERVER['SCRIPT_NAME'], '.php');

// Получаем карту сайта из базы данных
$main_menu = [];
try {
	// Выбираем все пункты, которые доступны нам по уровню даже невидимые
	if ($query = $db->query("SELECT * FROM main_menu WHERE menu_level <= $user_level ORDER BY menu_order ASC")) {
		while ($db_row = $query->fetch_array()) {
			addMenuPage($db_row['menu_url'], $db_row['menu_name'], $db_row['menu_status'], $db_row['menu_title']);
		}
		$query->close();
	}
} catch (Exception $e) {

}

/**	---------------------------------------------------------------------------------------------------------------------
 * Добавляет в массив главного меню новый пункт
 * @param string $url
 * @param string $name
 * @param ?string $title = null
 */
function addMenuPage(string $url, string $name, int $status, ?string $title = null) {
	global $main_menu;
	$menu_item = new stdClass();
	$menu_item->title = $title;
	$menu_item->name = $name;
	$menu_item->status = $status;
	$main_menu[$url] = $menu_item;
}

/**	---------------------------------------------------------------------------------------------------------------------
 * Переход на страницу по умолчанию
 */
function goToDefault() {
	global $main_menu;
	// Берём из массива адрес первой страницы
	$default_page = array_key_first($main_menu);
	if (is_null($default_page)) { $default_page = 'guide'; }
	header("Location: $default_page.php");
	exit();
}

/**	---------------------------------------------------------------------------------------------------------------------
 * Возвращает никнейм пользователя, если он есть, или ФИО, если они есть, или "Неизвестно"
 * @param $db_line Строка из базы данных в виде ассоциативного массива
 */
function getUserName($db_line) {
	$result = "Неизвестно";
	if (!is_null($db_line['user_nickname'])) {
		$result = $db_line['user_nickname'];
	} else if (!is_null($db_line['user_surname'])) {
		$result = $db_line['user_surname'] . " " . $db_line['user_name'] . " " . $db_line['user_patronymic'];
	}
	return $result;
}

/**	---------------------------------------------------------------------------------------------------------------------
 * Проверка прав доступа к странице
 */
function checkAccess(int $page_level) {
	global $user_level;
	if ($page_level > $user_level) { goToDefault(); }
}

/**	---------------------------------------------------------------------------------------------------------------------
 * Проверяет string значение на NULL для внесения в базу данных
 */
function getStringSql(?string $text) {
	if (is_null($text)) return "NULL";
	return "'$text'";
}

/**	---------------------------------------------------------------------------------------------------------------------
 * Проверяет string значение на правильность телефона для внесения в базу данных
 */
function getStringPhone(?string $text) {
	if (is_null($text)) return null;
	return preg_replace('/[^0-9]/', '', $text);
}

/**	---------------------------------------------------------------------------------------------------------------------
 * Пррверяет string значение на NULL для внесения в базу данных
 */
function setAlert(string $text) { if (isset($_SESSION['alert'])) { $_SESSION['alert'] .= '<br>'.$text; } else { $_SESSION['alert'] = $text; } }

/**	---------------------------------------------------------------------------------------------------------------------
 * Выбираем статьи, которые имеют статус "Опубликовано" из раздела текущей страницы, которые попадают во временные рамки публикации
 * @param string $current_page URL текущей страницы
 * @param int $from Начальная запись в запросе для отображения
 */
function getPostsSql(string $current_page, int $from) {
	return "SELECT * FROM `posts` 
	LEFT JOIN `users` ON `users`.`user_id` = `posts`.`post_author`
	LEFT JOIN `main_menu` ON `main_menu`.`menu_id` = `posts`.`post_chapter`
	LEFT JOIN `media` ON `media`.`media_post` = `posts`.`post_id`
	WHERE `posts`.`post_status` IN (" . STATUS_SHOW . ", " . STATUS_FIXED . ") 
	AND `main_menu`.`menu_url` = '" . $current_page . "'
	AND (ISNULL(`posts`.`post_start`) OR (NOW() >= `posts`.`post_start`))
	AND (ISNULL(`posts`.`post_end`) OR (NOW() <= `posts`.`post_end`))
	ORDER BY `posts`.`post_status` DESC, `posts`.`post_start` DESC LIMIT $from, ".POSTS_IN_PAGE;
}

/**
 * Отрисовка стены со статьями
 * @param int $from Начальная запись в запросе для отображения
 */
function drawGuidePosts(int $from) {
    global $db, $main_menu, $current_page;
    $count = POSTS_IN_PAGE;
    $posts = getPostsSql($current_page, $from);
    if ($query = $db->query($posts)) {
        while ($post = $query->fetch_array()) {
            drawPost($post['post_title'], getUserName($post), $post['post_text'], $post['post_create'], $post['media_url_name'], $post['media_title'], $post['post_file']);
            $count--;
        }
        $query->close();
    }
    return $count;
}

/**	---------------------------------------------------------------------------------------------------------------------
 * Отрисовка одной отдельной статьи
 * @param $title Заголовок статьи
 * @param $author Автор статьи
 * @param $text Текст статьи
 * @param $time Время создания статьи
 */
function drawPost(string $title, string $author, string $text, string $time, ?string $media, ?string $media_title, string $post_file) {
    print '<div class="post_info">';
    print '<div class="post_author">' . $author . '</div>';
	print '<div class="post_title">' . $title . '</div>';
	
	if (!is_null($media)) {
		print '<div class="media"><video controls="true" title="' . $title .'"><source src="' . MEDIA_PATH . '/media/' . $media . '"></video></div>';
	}
    print addTagP($text);
    print '</div>';
}

/**
 * Получить URL-аватарки пользователя
 */
function getAvatar() {
	global $user_id;
	$png = 'avatars/'.$user_id.'.png';
	$jpg = 'avatars/'.$user_id.'.jpg';
	if (is_file($png)) { return $png; } elseif (is_file($jpg)) { return $jpg; } else { return 'avatars/default.png';}
}

/**
 * Получить текстовую запись статуса объекта
 */
function getObjectStatus(int $status) {
	switch ($status) {
		case STATUS_SHOW: return 'Опубликован';
		case STATUS_HIDDEN: return 'Скрыт';
		case STATUS_CHECK: return 'На проверке';
		case STATUS_FIXED: return 'Закреплён';
		case STATUS_DRAFT: return 'Черновик';
		default: return 'Неизвестно';
	}
}
?>