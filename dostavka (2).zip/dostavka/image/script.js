function ak() {
    var oknoo = document.getElementById("zapisat");
    oknoo.style.display = 'flex';
  }
  
  function krest1() {
    var oknoo = document.getElementById("zapisat");
    oknoo.style.display = 'none';
  }

  function ak1() {
    var oknoo = document.getElementById("zapisat1");
    oknoo.style.display = 'flex';
  }
  
  function krest2() {
    var oknoo = document.getElementById("zapisat1");
    oknoo.style.display = 'none';
  }